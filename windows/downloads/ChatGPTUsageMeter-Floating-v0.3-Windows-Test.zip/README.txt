CHATGPT USAGE METER — Floating v0.3 (Windows test edition)

解压到普通文件夹，双击唯一的 ChatGPTUsageMeter.exe。

右键点击悬浮窗任意标签/空白处，或右键托盘图标：
· 语言 / Language → 简体中文 / English
· 背景颜色 / Background color → 深海蓝 / 炭灰 / 森林绿 / 暗紫
当前选择会显示勾选标记，立即生效；语言选择不再占用仪表空间。
两处菜单共用同一套选项。仅一个百分比托盘入口。

语言和背景偏好保存在 %LOCALAPPDATA%\CodexUsageMeter\preferences.json。
下次启动恢复；旧v0.2的language.txt会作为语言初值读取，原文件保留。
仅保存语言与颜色代码，不保存额度、账户或凭据。无法写入时显示“偏好未保存”。

拖动数字/标签移动窗口。菜单可显示、隐藏、刷新、重新定位、退出。
关闭窗口只隐藏；从托盘选择“退出浮条 / Exit meter”彻底退出。
不安装，不注册开机启动，不要求管理员权限。

数据属于本机官方Codex CLI当前登录账户的Codex额度，不是全部ChatGPT消息额度或API账单。
需要已有、已登录的npm版Codex CLI及.NET Framework。60秒查询，手动刷新最短10秒。
失败显示缓存；首次失败可能读取本地Codex会话日志，缓存账户身份未核验。

已验证：双语菜单与状态、两种偏好保存/恢复、旧偏好读取、保存失败提示、四种背景文字对比度、
中英文100/150/200%离屏布局、隐藏/恢复/重新定位/退出组件测试、实际新窗口代码官方取数、
新主进程路径/版本/响应状态。最终EXE经Defender扫描未发现威胁，但未签名。
未完成：真实鼠标菜单/托盘点击、拖动手感、多显示器实体跨屏DPI、睡眠唤醒、长期稳定性。
不要绕过系统安全拦截。源码包的预览使用标明的测试数据。

English
Open the only executable, ChatGPTUsageMeter.exe, after extracting the ZIP.
Right-click the floating meter or its tray icon for Language and Background color.
Choose Simplified Chinese/English and Dark navy/Charcoal/Forest green/Deep plum.
Checked choices apply immediately and are restored on restart. No settings toolbar occupies the meter.
Drag labels/numbers to move. Closing hides; choose Exit meter to quit.
Quota belongs to the local signed-in Codex CLI account. This is an unsigned portable test build.
Actual mouse/tray interaction, physical multi-monitor DPI, sleep/wake and long-running tests remain manual.
